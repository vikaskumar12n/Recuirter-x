


function Support(){
    return (
        <>
        <div className="container support_container">
            <div className="row">
                <div className="col-sm-6 ">
                <p className="supportcontent_section" style={{textAlign: "left", paddingTop: 60, color: "#db0249"}}>WHAT WE ARE DOING</p>
                <h1 className="supportcontent_section" style={{ textAlign: "left", color: "#1930a4"}}>24k Talented people <br />are getting jobs</h1>
                <p className="supportcontent_section" style={{ textAlign: "left"}}><b>Mollit anim laborum duis au dolor in voluptate velit <br /> ess cillum dolore eu lore dsu quality mollit anim <br /> laborumuis au dolor in voluptate velit cillum.</b></p>
                <p className="supportcontent_section" style={{ textAlign: "left"}}>Mollit anim laborum. Duis aute irufo dhjkolohr in re voluptate <br /> velit esscillumlore eu quife nrulla parihatur. Excghcepteur <br /> signjnt occa cupidatat non inulpadeserunt mollit aboru. <br /> temnthp incididunt ut labore mollit anim laborum suis aute <br /> velit esscillumlore eu quife nrulla parihatur.</p>
                <button className="btn_support mt-5" type="button">Post a job</button>
                </div>
                <div className="col-sm-6 supportImage_section">
                    <div className="supportImage_sectionContent">
                        <p>Since</p>
                        <p className="support_sinceSection">2024</p>
                    </div>
                </div>
            </div>
        </div>
        </>
    )
}

export default Support