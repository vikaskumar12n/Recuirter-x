
function Resumes()
{
    return(
        <>
        <div className="row resume_image mt-2">
        <div className=" blur">
        <div className="row">
            <div className="col-sm-3"></div>
            <div className="col-sm-6 text-center">
                <p className="mt-5 text-light">Featured Tour Package</p>
                <h1 className="text-light">make A Different online resume</h1>
                <button className="upload_resume text-light mt-5">Uploade your CV</button>
            </div>
            <div className="col-sm-3"></div>
        </div>
        </div>
        </div>
        </>
    )
}
export default Resumes;